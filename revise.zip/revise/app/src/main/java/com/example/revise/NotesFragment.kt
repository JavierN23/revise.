package com.example.revise

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
class NotesFragment : Fragment() {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, saveInstanceState: Bundle?):
            View {
        return inflater.inflate(R.layout.fragment_notes, container, false)
    }
    companion object {
        private const val ARG_SUBJECT_ID = "subject_id"

        fun newInstance(subjectId: Int): NotesFragment {
            return NotesFragment().apply {

                arguments = Bundle().apply {
                    putInt(ARG_SUBJECT_ID, subjectId)
                }
            }
        }
    }
}