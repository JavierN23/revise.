
package com.example.revise

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        // Apply padding to prevent the app from overlapping
        ViewCompat.setOnApplyWindowInsetsListener(
            findViewById(R.id.mainRoot)
        ) { view, insets ->

            val systemBars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars()
            )

            view.setPadding(
                systemBars.left,
                systemBars.top,
                systemBars.right,
                systemBars.bottom
            )

            insets
        }

        // Find the bottom navigation bar from activity_main.xml.
        val bottomNavigation = findViewById<BottomNavigationView>(
            R.id.bottomNavigation
        )

        // Listen for taps on the bottom navigation items.
        bottomNavigation.setOnItemSelectedListener { item ->

            // Determine which Fragment corresponds
            val selectedFragment = when (item.itemId) {

                R.id.nav_home -> HomeFragment()

                R.id.nav_subjects -> SubjectsFragment()

                R.id.nav_ai_tutor -> AITutorFragment()

                else -> null
            }

            // Display the selected Fragment.
            if (selectedFragment != null) {

                supportFragmentManager.beginTransaction()
                    .replace(
                        R.id.fragment_container,
                        selectedFragment
                    )
                    .commit()

                // Indicate that the navigation event was handled.
                true

            } else {
                false
            }
        }

        if (savedInstanceState == null) {

            supportFragmentManager.beginTransaction()
                .replace(
                    R.id.fragment_container,
                    HomeFragment()
                )
                .commit()


            bottomNavigation.menu
                .findItem(R.id.nav_home)
                .isChecked = true
        }
    }
}
