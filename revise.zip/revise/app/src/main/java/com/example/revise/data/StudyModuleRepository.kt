package com.example.revise.data

import kotlinx.coroutines.flow.Flow

class StudyModuleRepository(private val moduleDao: StudyModuleDao) {
    fun getModuleForSubject(subjectId: Int): Flow<List<StudyModule>> {
        return moduleDao.getModulesForSubject(subjectId)
    }

    suspend fun insertModule(module: StudyModule) {
        moduleDao.insertModule(module)
    }

    suspend fun deleteModule(moduleId: Int) {
        moduleDao.deleteModule(moduleId)
    }

}