
package com.example.revise

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color

import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

import com.example.revise.adapter.SubjectAdapter
import com.example.revise.data.AppDatabase
import com.example.revise.data.Subject
import com.example.revise.data.SubjectRepository
import com.example.revise.viewmodel.SubjectsViewModel
import com.example.revise.viewmodel.SubjectsViewModelFactory

import kotlinx.coroutines.launch
class SubjectsFragment : Fragment() {

    // ViewModel communicates with Room through the repository.
    private lateinit var subjectsViewModel: SubjectsViewModel

    // Creates the Subjects screen.
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        return inflater.inflate(
            R.layout.fragment_subjects,
            container,
            false
        )
    }

    // Called after the Fragment's layout has been created.
    override fun onViewCreated(
        view: View,
        savedInstanceState: Bundle?
    ) {
        super.onViewCreated(view, savedInstanceState)

        // Get the shared Room database instance.
        val database = AppDatabase.getDatabase(requireContext())

        // Create the repository using our DAO.
        val repository = SubjectRepository(database.subjectDao())

        // Create the ViewModel factory.
        val factory = SubjectsViewModelFactory(repository)

        // Initialize our SubjectsViewModel.
        subjectsViewModel = ViewModelProvider(
            this,
            factory
        )[SubjectsViewModel::class.java]

        // Find the subject list and empty-state message.
        val subjectsRecyclerView =
            view.findViewById<RecyclerView>(
                R.id.subjectsRecyclerView
            )

        val emptySubjectsView =
            view.findViewById<View>(
                R.id.emptySubjectsView
            )

        // Create the adapter for displaying subjects.
        val subjectAdapter = SubjectAdapter(

            // Called when a student selects Delete.
            onDeleteSubject = { subject ->

                // Show confirmation before deleting.
                showDeleteSubjectDialog(subject)
            },

            // Called when a student taps a subject card.
            onSubjectClick = { subject ->

                // Create a dashboard for the selected subject.
                val dashboard =
                    SubjectDashboardFragment.newInstance(
                        subject.id,
                        subject.name
                    )

                // Open the dashboard.
                // Save the current screen in the back stack.
                parentFragmentManager.beginTransaction()
                    .replace(
                        R.id.fragment_container,
                        dashboard
                    )
                    .addToBackStack(null)
                    .commit()
            }
        )

        // Display subjects vertically.
        subjectsRecyclerView.layoutManager =
            LinearLayoutManager(requireContext())

        // Connect the adapter to RecyclerView.
        subjectsRecyclerView.adapter = subjectAdapter

        // Collect Room updates while the screen is started.
        viewLifecycleOwner.lifecycleScope.launch {

            viewLifecycleOwner.repeatOnLifecycle(
                Lifecycle.State.STARTED
            ) {

                subjectsViewModel.allSubjects.collect { subjects ->

                    // Update the visible subject cards.
                    subjectAdapter.updateSubjects(subjects)

                    // Display the empty-state message only
                    // when no subjects are saved.
                    if (subjects.isEmpty()) {

                        emptySubjectsView.visibility = View.VISIBLE
                        subjectsRecyclerView.visibility = View.GONE

                    } else {

                        emptySubjectsView.visibility = View.GONE
                        subjectsRecyclerView.visibility = View.VISIBLE
                    }
                }
            }
        }
        val addSubjectButton =
            view.findViewById<Button>(
                R.id.addSubjectButton
            )
        // Open the Add Subject dialog.
        addSubjectButton.setOnClickListener {
            showAddSubjectDialog()
        }
    }
    // Displays a dialog for creating a new subject.
    private fun showAddSubjectDialog() {
        // Create the subject name input.
        val subjectInput = EditText(requireContext())

        subjectInput.hint = "Subject name"
        subjectInput.setSingleLine(true)
        // Set the entered text color.
        subjectInput.setTextColor(
            ContextCompat.getColor(
                requireContext(),
                R.color.text_primary
            )
        )
        // Set the hint text color.
        subjectInput.setHintTextColor(
            ContextCompat.getColor(
                requireContext(),
                R.color.text_secondary
            )
        )
        // Convert dp to pixels for consistent spacing.
        val density = resources.displayMetrics.density

        val horizontalPadding = (24 * density).toInt()
        val verticalPadding = (8 * density).toInt()

        // Create a container for the input field.
        val container = LinearLayout(requireContext())

        container.setPadding(
            horizontalPadding,
            verticalPadding,
            horizontalPadding,
            verticalPadding
        )

        container.addView(
            subjectInput,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )
        // Create a custom white dialog title.
        val dialogTitle = TextView(requireContext()).apply {

            text = "Add Subject"

            setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.text_primary
                )
            )

            textSize = 20f

            setPadding(
                horizontalPadding,
                (24 * density).toInt(),
                horizontalPadding,
                (12 * density).toInt()
            )
        }
        // Build the Add Subject dialog.
        val dialog = AlertDialog.Builder(requireContext())

            .setCustomTitle(dialogTitle)

            .setView(container)

            // Save the subject when Add is pressed.
            .setPositiveButton("Add") { _, _ ->

                val subjectName =
                    subjectInput.text.toString().trim()

                // Prevent saving empty subject names.
                if (subjectName.isNotEmpty()) {

                    // Save the subject through the ViewModel.
                    subjectsViewModel.addSubject(subjectName)
                }
            }
            // Close without saving.
            .setNegativeButton("Cancel", null)

            .create()

        // Display the dialog.
        dialog.show()

        // Apply the rounded midnight-blue background.
        dialog.window?.setBackgroundDrawableResource(
            R.drawable.bg_add_subject_dialog
        )

        // Set the Add button color to blue.
        dialog.getButton(AlertDialog.BUTTON_POSITIVE)
            .setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.accent_blue
                )
            )
        // Set the Cancel button color.
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE)
            .setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.text_secondary
                )
            )
    }
    // Displays a confirmation dialog before deleting a subject.
    private fun showDeleteSubjectDialog(subject: Subject) {

        // Convert dp to pixels.
        val density = resources.displayMetrics.density
        val horizontalPadding = (24 * density).toInt()

        // Create a white dialog title.
        val dialogTitle = TextView(requireContext()).apply {

            text = "Delete Subject"

            setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.text_primary
                )
            )

            textSize = 20f

            setPadding(
                horizontalPadding,
                (24 * density).toInt(),
                horizontalPadding,
                (12 * density).toInt()
            )
        }
        // Build the Delete Subject confirmation dialog.
        val dialog = AlertDialog.Builder(requireContext())

            .setCustomTitle(dialogTitle)

            .setMessage(
                "Are you sure you want to delete ${subject.name}?"
            )

            // Delete the selected subject from Room.
            .setPositiveButton("Delete") { _, _ ->

                subjectsViewModel.deleteSubject(subject.id)
            }

            // Cancel without deleting.
            .setNegativeButton("Cancel", null)

            .create()

        // Display the dialog.
        dialog.show()

        // Apply the existing dark rounded background.
        dialog.window?.setBackgroundDrawableResource(
            R.drawable.bg_add_subject_dialog
        )
        // Make the confirmation message readable.
        dialog.findViewById<TextView>(
            android.R.id.message
        )?.setTextColor(
            ContextCompat.getColor(
                requireContext(),
                R.color.text_primary
            )
        )
        // Make Delete red to indicate a destructive action.
        dialog.getButton(AlertDialog.BUTTON_POSITIVE)
            .setTextColor(
                Color.parseColor("#FF6B6B")
            )
        // Make Cancel muted blue-gray.
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE)
            .setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.text_secondary
                )
            )
    }
}
