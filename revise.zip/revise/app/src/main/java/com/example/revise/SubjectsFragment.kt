
package com.example.revise

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment

class SubjectsFragment : Fragment() {

    // Creates the Subjects screen using fragment_subjects.xml.
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        return inflater.inflate(
            R.layout.fragment_subjects,
            container,
            false
        )
    }

    // Called after the Fragment's layout is created.
    override fun onViewCreated(
        view: View,
        savedInstanceState: Bundle?
    ) {
        super.onViewCreated(view, savedInstanceState)

        // Find the Add Subject button in the XML layout.
        val addSubjectButton =
            view.findViewById<Button>(R.id.addSubjectButton)

        // Open the dialog when the button is pressed.
        addSubjectButton.setOnClickListener {
            showAddSubjectDialog()
        }
    }

    // Displays the Add Subject dialog.
    private fun showAddSubjectDialog() {

        // Create a text field for entering a subject name.
        val subjectInput = EditText(requireContext())

        subjectInput.hint = "Subject name"
        subjectInput.setSingleLine(true)

        subjectInput.setTextColor(
            ContextCompat.getColor(
                requireContext(),
                R.color.text_primary
            )
        )

        subjectInput.setHintTextColor(
            ContextCompat.getColor(
                requireContext(),
                R.color.text_secondary
            )
        )

        // Create a container to add spacing around the input.
        val container = LinearLayout(requireContext())

        val density = resources.displayMetrics.density

        val horizontalPadding = (24 * density).toInt()
        val verticalPadding = (8 * density).toInt()

        container.setPadding(
            horizontalPadding,
            verticalPadding,
            horizontalPadding,
            verticalPadding
        )

        container.addView(
            subjectInput,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )

        val dialogTitle = TextView(requireContext()).apply {

            text = "Add Subject"

            setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.text_primary
                )
            )

            textSize = 20f

            setPadding(
                horizontalPadding,
                (24 * density).toInt(),
                horizontalPadding,
                (12 * density).toInt()
            )
        }

        val dialog = AlertDialog.Builder(requireContext())

            .setCustomTitle(dialogTitle)

            // Display the subject name input.
            .setView(container)

            .setPositiveButton("Add") { _, _ ->

                // Read the entered name and remove extra spaces.
                val subjectName =
                    subjectInput.text.toString().trim()

                if (subjectName.isNotEmpty()) {

                    Toast.makeText(
                        requireContext(),
                        "Subject: $subjectName",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }

            .setNegativeButton("Cancel", null)

            .create()

        // Show the dialog before accessing its buttons.
        dialog.show()

        // Apply our custom midnight-blue background
        dialog.window?.setBackgroundDrawableResource(
            R.drawable.bg_add_subject_dialog
        )

        // Make the Add button bright blue.
        dialog.getButton(AlertDialog.BUTTON_POSITIVE)
            .setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.accent_blue
                )
            )

        // Make the Cancel button muted blue-gray.
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE)
            .setTextColor(
                ContextCompat.getColor(
                    requireContext(),
                    R.color.text_secondary
                )
            )
    }
}
