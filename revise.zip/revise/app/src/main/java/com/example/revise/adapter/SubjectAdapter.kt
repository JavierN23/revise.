
package com.example.revise.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.revise.R
import com.example.revise.data.Subject
import java.util.Locale
import android.widget.PopupMenu
class SubjectAdapter (private val onDeleteSubject: (Subject) -> Unit, private val onSubjectClick: (Subject) -> Unit) :
    RecyclerView.Adapter<SubjectAdapter.SubjectViewHolder>() {

    // List of subjects currently displayed.
    private var subjects: List<Subject> = emptyList()

    // Holds references to views inside each subject card.
    class SubjectViewHolder(view: View) :
        RecyclerView.ViewHolder(view) {

        val initials: TextView =
            view.findViewById(R.id.subjectInitials)

        val name: TextView =
            view.findViewById(R.id.subjectNameText)

        val menuButton: TextView =
            view.findViewById(R.id.subjectMenuButton)
    }

    // Creates a new subject card.
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): SubjectViewHolder {

        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_subject, parent, false)

        return SubjectViewHolder(view)
    }

    // Populates the card with the subject's information.
    override fun onBindViewHolder(
        holder: SubjectViewHolder,
        position: Int)
    {
        val subject = subjects[position]

        // Display the complete subject name.
        holder.name.text = subject.name

        // Generate initials from the subject name.
        holder.initials.text = generateInitials(subject.name)

        holder.itemView.setOnClickListener {
            onSubjectClick(subject)
        }

        holder.menuButton.setOnClickListener { clickedView ->

            val popupContext = androidx.appcompat.view.ContextThemeWrapper(clickedView.context,R.style.RevisePopupMenu)
            val popupMenu = androidx.appcompat.widget.PopupMenu(popupContext,clickedView)

            popupMenu.menu.add("Delete").setOnMenuItemClickListener {
                onDeleteSubject(subject)

                true
            }

            popupMenu.show()
        }
    }

    // Number of subjects displayed.
    override fun getItemCount(): Int = subjects.size

    // Update the subjects displayed by RecyclerView.
    fun updateSubjects(newSubjects: List<Subject>) {
        subjects = newSubjects
        notifyDataSetChanged()
    }

    // Generate up to two initials. I feel like setting an icon for each would be too much.
    private fun generateInitials(name: String): String {

        val words = name.trim()
            .split(Regex("\\s+"))
            .filter { it.isNotEmpty() }

        return words.take(2)
            .map { it.take(1).uppercase(Locale.getDefault()) }
            .joinToString("")
    }
}
