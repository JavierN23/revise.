package com.example.revise.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope

import com.example.revise.data.SubjectRepository
import com.example.revise.data.Subject

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

import android.util.Log

class SubjectsViewModel(private val repository: SubjectRepository): ViewModel() {
    val allSubjects: Flow<List<Subject>> = repository.allSubject


    fun addSubject(subjectName: String) {

        // Remove unnecessary spaces.
        val name = subjectName.trim()

        if (name.isEmpty()) return

        // Confirm the ViewModel received the subject.
        Log.d("ReviseDatabase", "Saving subject: $name")

        viewModelScope.launch {

            try {
                // Create and save the subject.
                val subject = Subject(name = name)
                repository.insertSubject(subject)

                // This executes only if insertion completes.
                Log.d(
                    "ReviseDatabase",
                    "Subject inserted successfully: $name"
                )

            } catch (e: Exception) {

                // Display any database insertion errors.
                Log.e(
                    "ReviseDatabase",
                    "Failed to save subject",
                    e
                )
            }
        }
    }


    fun deleteSubject(subjectId: Int) {
        viewModelScope.launch {
            repository.deleteSubject(subjectId)
        }
    }
}

class SubjectsViewModelFactory(private val repository: SubjectRepository): ViewModelProvider.Factory {

    @Suppress("UNCHECK_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(SubjectsViewModel::class.java)) {
            return SubjectsViewModel(repository) as T
        }

        throw IllegalArgumentException("Unknown ViewModel class")
    }

}