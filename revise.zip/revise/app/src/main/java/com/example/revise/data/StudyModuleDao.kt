
package com.example.revise.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

// Defines database operations for study modules.
@Dao
interface StudyModuleDao {

    // Saves a new module to Room.
    @Insert
    suspend fun insertModule(module: StudyModule)

    // Retrieves modules belonging to a specific subject.
    @Query(
        "SELECT * FROM modules " +
                "WHERE subjectId = :subjectId " +
                "ORDER BY id ASC"
    )
    fun getModulesForSubject(
        subjectId: Int
    ): Flow<List<StudyModule>>

    // Deletes a module using its ID.
    @Query("DELETE FROM modules WHERE id = :moduleId")
    suspend fun deleteModule(moduleId: Int)
}
