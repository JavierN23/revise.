
package com.example.revise.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
// Represents a module belonging to a specific subject.
@Entity(
    tableName = "modules",
    foreignKeys = [
        ForeignKey(
            entity = Subject::class,
            parentColumns = ["id"],
            childColumns = ["subjectId"],

            // Delete the module when its subject is deleted.
            onDelete = ForeignKey.CASCADE
        )
    ],

    indices = [Index(value = ["subjectId"])]
)
data class StudyModule(

    // Unique ID generated for each module.
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,

    // ID of the subject this module belongs to.
    val subjectId: Int,

    // Name entered.
    val name: String
)
