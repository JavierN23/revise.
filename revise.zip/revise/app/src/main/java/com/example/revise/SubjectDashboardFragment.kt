
package com.example.revise

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import android.widget.Button

// Displays the dashboard for a selected subject.
class SubjectDashboardFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        // Load the subject dashboard layout.
        return inflater.inflate(
            R.layout.fragment_subject_dashboard,
            container,
            false
        )
    }

    override fun onViewCreated(
        view: View,
        savedInstanceState: Bundle?
    ) {
        super.onViewCreated(view, savedInstanceState)

        // Retrieve the subject ID passed from SubjectsFragment.
        val subjectId = requireArguments().getInt("subject_id")

        // Get the selected subject's name.
        val subjectName =
            requireArguments().getString(ARG_SUBJECT_NAME)
                ?: "Subject"

        // Display the subject name in the header.
        val subjectTitle =
            view.findViewById<TextView>(R.id.subjectDashboardTitle)

        subjectTitle.text = subjectName

        val backButton =
            view.findViewById<TextView>(R.id.backToSubjectsButton)

        backButton.setOnClickListener {
            parentFragmentManager.popBackStack()
        }

        val openNotesButton =
            view.findViewById<Button>(R.id.openNotesButton)

        openNotesButton.setOnClickListener {
            val notesFragment = NotesFragment.newInstance(subjectId)

            parentFragmentManager.beginTransaction()
                .replace(R.id.fragment_container, notesFragment)
                .addToBackStack(null)
                .commit()
        }
    }

    companion object {

        private const val ARG_SUBJECT_ID = "subject_id"
        private const val ARG_SUBJECT_NAME = "subject_name"

        // Creates a dashboard for a specific subject.
        fun newInstance(
            subjectId: Int,
            subjectName: String
        ): SubjectDashboardFragment {

            return SubjectDashboardFragment().apply {

                arguments = Bundle().apply {
                    putInt(ARG_SUBJECT_ID, subjectId)
                    putString(ARG_SUBJECT_NAME, subjectName)
                }
            }
        }
    }
}