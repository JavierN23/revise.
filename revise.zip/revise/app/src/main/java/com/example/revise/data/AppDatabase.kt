
package com.example.revise.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [Subject::class, StudyModule::class],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    // Provides access to subject database operations.
    abstract fun subjectDao(): SubjectDao

    abstract fun studyModuleDao(): StudyModuleDao

    companion object {

        // Holds the shared database instance.
        @Volatile
        private var INSTANCE: AppDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {

                db.execSQL(
                    """
                    CREATE TABLE IF NOT EXISTS `modules` (
                        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        `subjectId` INTEGER NOT NULL,
                        `name` TEXT NOT NULL,
                        FOREIGN KEY(`subjectId`)
                        REFERENCES `subjects`(`id`)
                        ON UPDATE NO ACTION
                        ON DELETE CASCADE
                    )
                    """.trimIndent()
                )

                db.execSQL(
                    """
                    CREATE INDEX IF NOT EXISTS
                    `index_modules_subjectId`
                    ON `modules` (`subjectId`)
                    """.trimIndent()
                )
            }
        }

        // Returns the database, creating it if necessary.
        fun getDatabase(context: Context): AppDatabase {

            return INSTANCE ?: synchronized(this) {

                // Create the database using application context.
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "revise_database"
                )
                    .addMigrations(MIGRATION_1_2)
                    .build()

                // Store the instance for future use.
                INSTANCE = instance
                instance
            }
        }
    }
}
